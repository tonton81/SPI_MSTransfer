/*
  MIT License

  Copyright (c) 2018 Antonio Alexander Brewer (tonton81) - https://github.com/tonton81

  Contributors:
  Tim - https://github.com/Defragster
  Mike - https://github.com/mjs513

  Designed and tested for PJRC Teensy 3.2, 3.5, and 3.6 boards.

  Forum link : https : //forum.pjrc.com/threads/50008-Project-SPI_MSTransfer

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/


#include "SPI_MSTransfer.h"
#include "Stream.h"
#include <SPI.h>
#include "circular_buffer.h"
#include <i2c_t3.h>
#include <EEPROM.h>
#include <functional>
#include <atomic>

_master_handler_ptr SPI_MSTransfer::_master_handler = nullptr; // MASTER
_master_handler_ptr_uint8_t SPI_MSTransfer::_master_handler_uint8_t = nullptr; // MASTER
Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> SPI_MSTransfer::mtsca; // BOTH
Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> SPI_MSTransfer::stmca; // BOTH
_wire_onReceive SPI_MSTransfer::_wire_onReceivefunc = nullptr; // MASTER
_detectPtr SPI_MSTransfer::_slaveDetectHandler = nullptr; // MASTER
volatile bool SPI_MSTransfer::_wire_callback_active = 0; // SLAVE
volatile uint8_t SPI_MSTransfer::_wire_callback_readpos = 0; // SLAVE
std::atomic<bool> SPI_MSTransfer::_slave_data_available = ATOMIC_FLAG_INIT; // MASTER

void SPI_MSTransfer::onTransfer(_slave_handler_ptr handler) {
  _master_handler = handler;
}
void SPI_MSTransfer::onTransfer(_slave_handler_ptr_uint8_t handler) {
  _master_handler_uint8_t = handler;
}
SPI_MSTransfer::SPI_MSTransfer(const char *data, uint8_t cs, SPIClass *SPIWire, uint32_t spi_bus_speed) {
  chip_select = cs; spi_port = SPIWire; _spi_bus_speed = spi_bus_speed;
  ::pinMode(cs, OUTPUT); // make sure CS is OUTPUT before deassertion.
  ::digitalWriteFast(cs, HIGH); // deassert the CS way before SPI initializes :)
  if ( spi_bus_speed >= 12000000 ) _delay_before_deassertion = 0;
  debugSerial = nullptr;
  spi_port->begin();
  if ( !strcmp(data, "Serial")       ) _serial_port_identifier = 0;
  else if ( !strcmp(data, "Serial1") ) _serial_port_identifier = 1;
  else if ( !strcmp(data, "Serial2") ) _serial_port_identifier = 2;
  else if ( !strcmp(data, "Serial3") ) _serial_port_identifier = 3;
  else if ( !strcmp(data, "Serial4") ) _serial_port_identifier = 4;
  else if ( !strcmp(data, "Serial5") ) _serial_port_identifier = 5;
  else if ( !strcmp(data, "Serial6") ) _serial_port_identifier = 6;
  else if ( !strcmp(data, "EEPROM")  ) eeprom_support = 1;
  else if ( !strcmp(data, "Wire") ) wire_port = 0;
  else if ( !strcmp(data, "Wire1") ) wire_port = 1;
  else if ( !strcmp(data, "Wire2") ) wire_port = 2;
  else if ( !strcmp(data, "Wire3") ) wire_port = 3;
  else if ( !strcmp(data, "SPI1") ) remote_spi_port = 1;
  else if ( !strcmp(data, "SPI2") ) remote_spi_port = 2;
  else if ( !strcmp(data, "FastLED" ) ) fastled_support = 1;
  else if ( !strcmp(data, "SERVO") ) servo_support = 1;

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  if ( SPIWire == (SPIClass*)&SPI ) _spi_port_memorymap = 0x4002C000;
  if ( SPIWire == (SPIClass*)&SPI1 ) _spi_port_memorymap = 0x4002D000;
  if ( SPIWire == (SPIClass*)&SPI2 ) _spi_port_memorymap = 0x400AC000;
#elif defined(KINETISL)
  if ( SPIWire == (SPIClass*)&SPI ) _spi_port_memorymap = 0x40076000;
  if ( SPIWire == (SPIClass*)&SPI1 ) _spi_port_memorymap = 0x40077000;
#endif
}
void SPI_MSTransfer::debug(Stream &serial) {
  debugSerial = &serial;
  Serial.print("DBG: [S_CS "); Serial.print(chip_select);
  Serial.print("] CB Capacity: "); Serial.print(mtsca.capacity());
  Serial.print(" Length: "); Serial.println(mtsca.max_size());
}
void SPI_MSTransfer::SPI_assert() {
  spi_port->beginTransaction(SPISettings(_spi_bus_speed, MSBFIRST, SPI_MODE0)); ::digitalWriteFast(chip_select, LOW);
}
void SPI_MSTransfer::SPI_deassert() {
  delayMicroseconds(_delay_before_deassertion);
  ::digitalWriteFast(chip_select, HIGH);
  spi_port->endTransaction();
}

bool SPI_MSTransfer::command_ack_response(uint16_t *data, uint32_t len) {
  uint8_t resend_count = 0; uint32_t timeout = micros(); uint16_t _crc = 0;
  while ( 1 ) {
    _crc = _transfer16_write(0xFFFF);
    if ( _crc == 0xF00D ) {
      _transfer16_write(0xBEEF); break;
    }
    else if ( _crc == 0xBAAD || micros() - timeout > 10000 ) {
      resend_count++;
      if ( resend_count > 3 ) {
        if ( debugSerial != nullptr ) {
          Serial.print("DBG: [S_CS "); Serial.print(chip_select);
          Serial.print("] FAIL_RES #"); Serial.print(resend_count);
          Serial.println(" Tx ABORT. "); delay(1000);
        }
        SPI_deassert(); return 0;
      }
      if ( debugSerial != nullptr ) {
        Serial.print("FAIL_Res #"); Serial.print(resend_count);
        Serial.println(" RETRY..."); delay(1000);
      }
      _transfer16_write(0xBEEF);
      SPI_deassert();
      delayMicroseconds(50);
      SPI_assert();
      for ( uint16_t i = 0; i < len; i++ ) _transfer16_write(data[i]);
      timeout = micros();
    }
  }
  return 1;
}
void SPI_MSTransfer::digitalWriteFast(uint8_t pin, bool state) {
  digitalWrite(pin, state);
}
void SPI_MSTransfer::digitalWrite(uint8_t pin, bool state) {
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x9766; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = ((uint16_t)(pin << 8) | state); checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) {
    _transfer16_write(data[i]);
  }
  if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return;
      }
    }
  }
  SPI_deassert(); return;
}
bool SPI_MSTransfer::digitalReadFast(uint8_t pin) {
  return digitalRead(pin);
}
bool SPI_MSTransfer::digitalRead(uint8_t pin) {
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x9766; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return buf[2];
      }
    }
  }
  SPI_deassert(); return 0;
}
void SPI_MSTransfer::pinMode(uint8_t pin, uint8_t state) {
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x9766; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = ((uint16_t)(pin << 8) | state); checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return;
      }
    }
  }
  SPI_deassert(); return;
}
void SPI_MSTransfer::pinToggle(uint8_t pin) { // code written by defragster
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x9766; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return;
      }
    }
  }
  SPI_deassert(); return;
}
uint8_t SPI_MSTransfer::transfer(uint8_t *buffer, uint16_t length, uint16_t packetID, uint8_t fire_and_forget) {
  uint16_t len = ( !(length % 2) ) ? ( length / 2 ) : ( length / 2 ) + 1;
  uint16_t data[6 + len], checksum = 0, data_pos = 0;
  data[data_pos] = ( fire_and_forget ) ? 0x9254 : 0x9253; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = length; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = packetID; checksum ^= data[data_pos]; data_pos++;
  bool odd_or_even = ( (length % 2) );
  for ( uint16_t i = 0; i < length; i += 2 ) {
    if ( odd_or_even ) {
      if ( i + 1 < length ) {
        data[data_pos] = ((uint16_t)(buffer[i] << 8) | buffer[i + 1]); checksum ^= data[data_pos]; data_pos++;
      }
      else {
        data[data_pos] = buffer[i]; checksum ^= data[data_pos]; data_pos++;
      }
    }
    else {
      data[data_pos] = ((uint16_t)(buffer[i] << 8) | buffer[i + 1]); checksum ^= data[data_pos]; data_pos++;
    }
  }
  data[data_pos] = checksum;
  if ( fire_and_forget == 1 ) {
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    uint32_t timeout = millis();
    while ( _transfer16_writeread(0xFFFF) != 0xBABE && millis() - timeout < 100 );
    _transfer16_write(0xD0D0); // send confirmation
    SPI_deassert();
    return data[4]; // F&F, RETURN PACKETID
  }
  else if ( fire_and_forget == 2 ) {
    mtsca.push_back(data, data[1]);
    return data[4];
  }
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return buf[2];
      }
    }
  }
  SPI_deassert();
  return 0;
}
uint16_t SPI_MSTransfer::transfer16(uint16_t *buffer, uint16_t length, uint16_t packetID, uint8_t fire_and_forget) {
  uint16_t data[6 + length], checksum = 0, data_pos = 0;
  data[data_pos] = ( fire_and_forget ) ? 0x9244 : 0x9243; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = length; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = packetID; checksum ^= data[data_pos]; data_pos++;
  for ( uint16_t i = 0; i < length; i++ ) {
    data[data_pos] = buffer[i];
    checksum ^= data[data_pos];
    data_pos++;
  }
  data[data_pos] = checksum;
  if ( fire_and_forget == 1 ) {
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    uint32_t timeout = millis();
    while ( _transfer16_writeread(0xFFFF) != 0xBABE && millis() - timeout < 100 );
    _transfer16_write(0xD0D0); // send confirmation
    SPI_deassert();
    return data[4]; // F&F, RETURN PACKETID
  }
  else if ( fire_and_forget == 2 ) {
    mtsca.push_back(data, data[1]);
    return data[4];
  }
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return buf[2];
      }
    }
  }
  SPI_deassert();
  return 0;
}


void SPI_MSTransfer::LCmode(uint8_t reads, uint8_t writes) {
  LC_delays = (uint16_t)(reads << 8) | writes;
}
uint16_t SPI_MSTransfer::_transfer16_write(uint16_t data) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  (*(KINETISK_SPI_t *)_spi_port_memorymap).SR = SPI_SR_TCF;
  (*(KINETISK_SPI_t *)_spi_port_memorymap).PUSHR = data | SPI_PUSHR_CTAS(1);
  while (!((*(KINETISK_SPI_t *)_spi_port_memorymap).SR & SPI_SR_TCF)) ; // wait
  if ( (uint8_t)LC_delays ) delayMicroseconds( (uint8_t)LC_delays );
  return (*(KINETISK_SPI_t *)_spi_port_memorymap).POPR;

#elif defined(KINETISL)
  (*(KINETISL_SPI_t *)_spi_port_memorymap).C2 = SPI_C2_SPIMODE;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).S;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).DL = data;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).DH = data >> 8;
  while (!((*(KINETISL_SPI_t *)_spi_port_memorymap).S & SPI_S_SPRF)) ; // wait
  if ( LC_delays >> 8 ) delayMicroseconds( LC_delays >> 8 );
  uint16_t r = (*(KINETISL_SPI_t *)_spi_port_memorymap).DL | ((*(KINETISL_SPI_t *)_spi_port_memorymap).DH << 8);
  (*(KINETISL_SPI_t *)_spi_port_memorymap).C2 = 0;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).S;
  return r;
#endif
}

uint16_t SPI_MSTransfer::_transfer16_writeread(uint16_t data) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  (*(KINETISK_SPI_t *)_spi_port_memorymap).SR = SPI_SR_TCF;
  (*(KINETISK_SPI_t *)_spi_port_memorymap).PUSHR = data | SPI_PUSHR_CTAS(1);
  while (!((*(KINETISK_SPI_t *)_spi_port_memorymap).SR & SPI_SR_TCF)) ; // wait
  if ( LC_delays >> 8 ) delayMicroseconds( LC_delays >> 8 );
  return (*(KINETISK_SPI_t *)_spi_port_memorymap).POPR;

#elif defined(KINETISL)
  (*(KINETISL_SPI_t *)_spi_port_memorymap).C2 = SPI_C2_SPIMODE;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).S;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).DL = data;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).DH = data >> 8;
  while (!((*(KINETISL_SPI_t *)_spi_port_memorymap).S & SPI_S_SPRF)) ; // wait
  if ( LC_delays >> 8 ) delayMicroseconds( LC_delays >> 8 );
  uint16_t r = (*(KINETISL_SPI_t *)_spi_port_memorymap).DL | ((*(KINETISL_SPI_t *)_spi_port_memorymap).DH << 8);
  (*(KINETISL_SPI_t *)_spi_port_memorymap).C2 = 0;
  (*(KINETISL_SPI_t *)_spi_port_memorymap).S;
  return r;
#endif
}






void SPI_MSTransfer::begin(uint32_t baudrate) { // set remote serial port and baud
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = baudrate >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = baudrate; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  if ( wire_port != -1 ) {
    begin_(I2C_SLAVE, (uint8_t)baudrate, 0, 0, 0, I2C_PULLUP_EXT, 100000, I2C_OP_MODE_ISR); return;
  }
}
int SPI_MSTransfer::read(void) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (int16_t)buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  if ( wire_port != -1 ) {
    if ( _wire_callback_active ) {
      if ( _wire_callback_readpos >= mtsca.peek_front()[4] ) return -1;
      uint8_t value = (uint8_t)mtsca.peek_front()[_wire_callback_readpos + 5];
      _wire_callback_readpos++;
      return value;
    }
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0008; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (int16_t)buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return -1;
}
size_t SPI_MSTransfer::read(uint8_t* buffer, size_t size) {
  if ( wire_port != -1 ) {
    if ( _wire_callback_active ) {
      uint8_t _shift = mtsca.peek_front()[4] - available();
      for ( uint16_t i = 0; i < size; i++ ) {
        if ( _wire_callback_readpos >= mtsca.peek_front()[4] ) break;
        buffer[i] = (uint8_t)mtsca.peek_front()[i + 5 + _shift];
        _wire_callback_readpos++;
      }
      if ( size >= mtsca.peek_front()[4] ) return mtsca.peek_front()[4] - _shift;
      return size;
    }
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0022; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 500; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          for ( uint16_t i = 0; i < ((uint32_t)(buf[2] << 16) | buf[3]); i++ ) buffer[i] = (uint8_t)buf[i + 4];
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return ((uint32_t)(buf[2] << 16) | buf[3]);
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
int SPI_MSTransfer::peek() {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (int16_t)buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  if ( wire_port != -1 ) {
    if ( _wire_callback_active ) {
      if ( _wire_callback_readpos >= mtsca.peek_front()[4] ) return -1;
      return (uint8_t)mtsca.peek_front()[_wire_callback_readpos + 5];
    }
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0009; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (int16_t)buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return -1;
}
int SPI_MSTransfer::available(void) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  if ( wire_port != -1 ) {
    if ( _wire_callback_active ) return mtsca.peek_front()[4] - _wire_callback_readpos;
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0007; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
size_t SPI_MSTransfer::write(const uint8_t *buf, size_t size) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[6 + size], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0004; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size; checksum ^= data[data_pos]; data_pos++;
    for ( uint16_t i = 0; i < size; i++ ) {
      data[data_pos] = buf[i];
      checksum ^= data[data_pos];
      data_pos++;
    }
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  if ( wire_port != -1 ) {
    uint16_t data[6 + size], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0005; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size; checksum ^= data[data_pos]; data_pos++;
    for ( uint16_t i = 0; i < size; i++ ) {
      data[data_pos] = buf[i];
      checksum ^= data[data_pos];
      data_pos++;
    }
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
void SPI_MSTransfer::flush() {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0005; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
size_t SPI_MSTransfer::print(const char *p) {
  write(p, strlen(p));
  return strlen(p);
}
size_t SPI_MSTransfer::println(const char *p) {
  char _text[strlen(p) + 1]; for ( uint16_t i = 0; i < strlen(p); i++ ) _text[i] = p[i]; _text[sizeof(_text) - 1] = '\n'; write(_text, sizeof(_text));
  return strlen(p) + 1;
}
int SPI_MSTransfer::read(int addr) {
  if ( eeprom_support != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x67BB; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = addr; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (int16_t)buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return 0;
}
void SPI_MSTransfer::write(int addr, uint8_t value) {
   if ( eeprom_support != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x67BB; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = addr; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = value; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert();
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::update(int addr, uint8_t value) {
  if ( eeprom_support != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x67BB; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = addr; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = value; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert();
        }
      }
    }
    SPI_deassert(); return;
  }
}
uint16_t SPI_MSTransfer::length() {
  if ( eeprom_support != -1 ) {
    uint16_t data[4], checksum = 0, data_pos = 0;
    data[data_pos] = 0x67BB; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return 0;
}
uint32_t SPI_MSTransfer::crc() {
  if ( eeprom_support != -1 ) {
    uint16_t data[4], checksum = 0, data_pos = 0;
    data[data_pos] = 0x67BB; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0004; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return ((uint32_t)buf[2] << 16 | buf[3]);
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return 0;
}
void SPI_MSTransfer::setTX(uint8_t pin, bool opendrain) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0006; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = ((uint16_t)(pin << 8) | opendrain); checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::setRX(uint8_t pin) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0007; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
bool SPI_MSTransfer::attachRts(uint8_t pin) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0008; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
bool SPI_MSTransfer::attachCts(uint8_t pin) {
  if ( _serial_port_identifier != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x3235; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0009; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = _serial_port_identifier; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
void SPI_MSTransfer::analogReadResolution(unsigned int bits) {
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x7429; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = bits; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return;
      }
    }
  }
  SPI_deassert(); return;
}
int SPI_MSTransfer::analogRead(uint8_t pin) {
  uint16_t data[5], checksum = 0, data_pos = 0;
  data[data_pos] = 0x7429; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return (int)buf[2];
      }
    }
  }
  SPI_deassert(); return 0;
}
uint32_t SPI_MSTransfer::analogWriteResolution(uint32_t bits) {
  uint16_t data[6], checksum = 0, data_pos = 0;
  data[data_pos] = 0x7429; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = bits >> 16; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = bits; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return ((uint32_t)buf[2] << 16 | buf[3]);
      }
    }
  }
  SPI_deassert(); return 0;
}
void SPI_MSTransfer::analogWrite(uint8_t pin, int val) {
  uint16_t data[6], checksum = 0, data_pos = 0;
  data[data_pos] = 0x7429; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = val; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  SPI_assert();
  for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
  if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
  for ( uint16_t i = 0; i < 3000UL; i++ ) {
    if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
      uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
      for ( uint16_t i = 2; i < buf[1]; i++ ) {
        delayMicroseconds(_transfer_slowdown_while_reading);
        buf[i] = _transfer16_writeread(0xFFFF);
        if ( i < buf[1] - 1 ) checksum ^= buf[i];
      }
      if ( checksum == buf[buf[1] - 1] ) {
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert(); return;
      }
    }
  }
  SPI_deassert(); return;
}
void SPI_MSTransfer::beginTransmission(uint8_t addr) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = addr; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          delayMicroseconds(300);
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
uint8_t SPI_MSTransfer::endTransmission(uint8_t sendStop) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = sendStop; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          delay(1); // crashes when lower
          SPI_deassert(); return (uint8_t)buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
void SPI_MSTransfer::setSDA(uint8_t pin) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::setSCL(uint8_t pin) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::setClock(uint32_t frequency) {
  if ( wire_port != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0006; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = frequency >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = frequency; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
uint8_t SPI_MSTransfer::requestFrom(uint8_t address, uint8_t length, uint8_t sendStop) {
  if ( wire_port != -1 ) {
    uint16_t data[8], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0010; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = address; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = length; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = sendStop; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
uint8_t SPI_MSTransfer::transfer(uint8_t spi_data) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = spi_data; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0xFF; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (uint8_t)buf[2];
        }
      }
    }
    SPI_deassert(); return 0xFF;
  }
  return 0;
}
uint16_t SPI_MSTransfer::transfer16(uint16_t spi_data) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = spi_data; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0xFFFF; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0xFFFF;
  }
  return 0;
}
uint32_t SPI_MSTransfer::transfer32(uint32_t spi_data) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = spi_data >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = spi_data; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0xFFFFFFFF; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return ((uint32_t)buf[2] << 16 | buf[3]);
        }
      }
    }
    SPI_deassert(); return 0xFFFFFFFF;
  }
  return 0;
}
void SPI_MSTransfer::beginTransaction(uint32_t baudrate, uint8_t msblsb, uint8_t dataMode) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[11], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = baudrate >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = baudrate; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = msblsb; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = dataMode; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = (uint16_t)remote_spi_pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = remote_spi_pin_assert; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::endTransaction() {
  if ( remote_spi_port != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0004; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = (uint16_t)remote_spi_pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = remote_spi_pin_assert; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::autoCS(int8_t pin, bool asserted) {
  if ( pin == -1 ) {
    if ( remote_spi_pin >= 0 ) pinMode(remote_spi_pin, INPUT);
    remote_spi_pin = pin;
    return;
  }
  pinMode(pin, OUTPUT);
  digitalWriteFast(pin, !asserted);
  remote_spi_pin = pin;
  remote_spi_pin_assert = asserted;
}
size_t SPI_MSTransfer::transfer16(const uint16_t *buf, size_t size) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6 + size], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0005; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size; checksum ^= data[data_pos]; data_pos++;
    for ( uint16_t i = 0; i < size; i++ ) {
      data[data_pos] = buf[i];
      checksum ^= data[data_pos];
      data_pos++;
    }
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
size_t SPI_MSTransfer::transfer(const uint8_t *buf, size_t size) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6 + size], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0006; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = size; checksum ^= data[data_pos]; data_pos++;
    for ( uint16_t i = 0; i < size; i++ ) {
      data[data_pos] = buf[i];
      checksum ^= data[data_pos];
      data_pos++;
    }
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
uint8_t SPI_MSTransfer::setCS(uint8_t pin) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0007; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return (uint8_t)buf[2];
        }
      }
    }
    SPI_deassert(); return 0;
  }
  return 0;
}
void SPI_MSTransfer::setMOSI(uint8_t pin) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0008; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::setMISO(uint8_t pin) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0009; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::setSCK(uint8_t pin) {
  if ( remote_spi_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0010; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pin; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::begin_(i2c_mode mode, uint8_t address1, uint8_t address2, uint8_t pinSCL, uint8_t pinSDA, i2c_pullup pullup, uint32_t rate, i2c_op_mode opMode) {
  if ( wire_port != -1 ) {
    uint16_t data[14], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0004; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = mode; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = address1; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = address2; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pinSCL; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pinSDA; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = pullup; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = rate >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = rate; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = opMode; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::setRate_(uint32_t busFreq, uint32_t i2cFreq) {
  if ( wire_port != -1 ) {
    uint16_t data[9], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0011; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = busFreq >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = busFreq; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = i2cFreq >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = i2cFreq; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
uint8_t SPI_MSTransfer::setOpMode(i2c_op_mode opMode) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0012; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = opMode; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
uint32_t SPI_MSTransfer::getClock() {
  if ( wire_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0013; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return ((uint32_t)(buf[2] << 16) | buf[3]);
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
void SPI_MSTransfer::resetBus() {
  if ( wire_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0014; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
  return;
}
void SPI_MSTransfer::onReceive(_wire_onReceive handler) {
  _wire_onReceivefunc = handler;
}
void SPI_MSTransfer::sendTransmission(i2c_stop sendStop) {
  if ( wire_port != -1 ) {
    uint16_t data[6], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0015; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = sendStop; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::sendRequest(uint8_t addr, size_t len, i2c_stop sendStop) {
  if ( wire_port != -1 ) {
    uint16_t data[9], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0016; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = addr; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = len >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = len; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = sendStop; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
void SPI_MSTransfer::setDefaultTimeout(uint32_t timeout) {
  if ( wire_port != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0017; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = timeout >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = timeout; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}
uint8_t SPI_MSTransfer::getSDA() {
  if ( wire_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0018; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
uint8_t SPI_MSTransfer::getSCL() {
  if ( wire_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0019; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
uint8_t SPI_MSTransfer::done() {
  if ( wire_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0020; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
uint8_t SPI_MSTransfer::finish(uint32_t timeout) {
  if ( wire_port != -1 ) {
    uint16_t data[7], checksum = 0, data_pos = 0;
    data[data_pos] = 0x66AA; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0021; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = wire_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = timeout >> 16; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = timeout; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return -1; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return buf[2];
        }
      }
    }
    SPI_deassert(); return -1;
  }
  return -1;
}
void SPI_MSTransfer::onDetect(_detectPtr handler) {
  _slaveDetectHandler = handler; std::bind(&SPI_MSTransfer::_onDetect, this);
  AsyncMST info;
  if ( _slaveDetectHandler != nullptr ) _slaveDetectHandler(info);
}
void SPI_MSTransfer::_onDetect() {
  AsyncMST info;
  _slaveDetectHandler(info);
}






















//void SPI_MSTransfer::show(uint8_t pin, CRGB *array, uint16_t array_length) { // update Fastled pixels
//}











































































void SPI_MSTransfer::begin() {
  if ( wire_port != -1 ) {
    begin_(I2C_MASTER, 0, 0, 0, 0, I2C_PULLUP_EXT, 100000, I2C_OP_MODE_ISR); return;
  }
  if ( remote_spi_port != -1 ) {
    uint16_t data[5], checksum = 0, data_pos = 0;
    data[data_pos] = 0x6A7B; checksum ^= data[data_pos]; data_pos++; // HEADER
    data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
    data[data_pos] = 0x0011; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
    data[data_pos] = remote_spi_port; checksum ^= data[data_pos]; data_pos++;
    data[data_pos] = checksum;
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return; // RECEIPT ACK
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          _transfer16_write(0xD0D0); // send confirmation
          SPI_deassert(); return;
        }
      }
    }
    SPI_deassert(); return;
  }
}

uint16_t SPI_MSTransfer::events(uint32_t MinTime) {
  static uint32_t LastTime = micros();
  if ( micros() - LastTime < MinTime ) return 0;
  LastTime = micros();


  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* CHECK STATUS FLAGS *///////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////

CHECK_FOR_REMAINING_DATA: // GOTO CALL WHEN PULLING SLAVE DATA
  {
    _slave_data_available = 0; // keep flag reset
    uint16_t value = 0, data[3] = { 0x98BB, 0x0003, 0x98B8 };
    uint32_t timeout = millis();
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    while ( ( ( value = _transfer16_writeread(0xFFFF) ) >> 8 ) != 0xAD && millis() - timeout < 100 );
    if ( value >> 8 == 0xAD ) {
      _transfer16_write(0xD0D0); // send confirmation
      SPI_deassert();
      ( (uint8_t)value >> 0 & 0x01 ) ? _slave_data_available = 1 : _slave_data_available = 0;
      ( (uint8_t)value >> 1 & 0x01 ) ? _slave_processing_busy = 1 : _slave_processing_busy = 0;
      if ( !((uint8_t)value >> 2 & 0x01) ) graceful_detect = 0;
      if ( (uint8_t)value >> 2 & 0x01 && graceful_detect++ >= 10 ) {
        AsyncMST info;
        if ( _slaveDetectHandler != nullptr ) _slaveDetectHandler(info);
        uint16_t data[3] = { 0x98BC, 0x0003, 0x98BF };
        SPI_assert();
        for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
        timeout = millis();
        while ( ( value = _transfer16_writeread(0xFFFF) ) != 0xBABE && millis() - timeout < 100 );
        _transfer16_write(0xD0D0); // send confirmation
        SPI_deassert();
      }
    }
  }



  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* TRANSFER SYSTEM QUEUES *///////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  if ( !_slave_processing_busy ) {
    while ( mtsca.size() ) {
      if ( debugSerial != nullptr ) {
        if ( mtsca.size() == mtsca.capacity() ) {
          Serial.print("DBG: [S_CS "); Serial.print(chip_select);
          Serial.println("] F&F MAX QUEUE REACHED");
        }
        else {
          Serial.print("DBG: [S_CS "); Serial.print(chip_select);
          Serial.print("] ");
          Serial.print(mtsca.size());
          Serial.print("/");
          Serial.print(mtsca.capacity());
          Serial.println(" DEQUEUE(S) LEFT");
        }
      }
      SPI_assert();
      uint16_t buffer[mtsca.peek_front()[1]];
      mtsca.pop_front(buffer, sizeof(buffer) / 2);
      for ( uint16_t i = 0; i < buffer[1]; i++ ) {
        _transfer16_write(buffer[i]);
      }
      uint32_t timeout = millis();
      while ( _transfer16_writeread(0xFFFF) != 0xBABE && millis() - timeout < 100 );
      _transfer16_write(0xD0D0); // send confirmation
      SPI_deassert();
    }
    { // SEND SIGNAL TO START PROCESSING
      uint16_t data[3] = { 0x99BB, 0x0003, 0x99B8 };
      SPI_assert();
      for ( uint16_t i = 0; i < data[1]; i++ ) {
        _transfer16_write(data[i]);
      }
      uint32_t timeout = millis();
      while ( _transfer16_writeread(0xFFFF) != 0xBABE && millis() - timeout < 100 );
      _transfer16_write(0xD0D0); // send confirmation
      SPI_deassert();
    }
  }



  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* GET CALLBACKS FROM SLAVE */////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  if ( _slave_data_available ) {
    uint16_t checksum = 0, data[4] = { 0x9712, 0x0004, 0x0000, 0x9716 };
    SPI_assert();
    for ( uint16_t i = 0; i < data[1]; i++ ) _transfer16_write(data[i]);
    if ( !command_ack_response(data, sizeof(data) / 2) ) return 0; // RECEIPT ACK
    bool _complete = 0;
    for ( uint16_t i = 0; i < 3000UL; i++ ) {
      if ( _complete ) break;
      if ( _transfer16_writeread(0xFFFF) == 0xAA55 ) {
        uint16_t buf[_transfer16_writeread(0xFFFF)]; buf[0] = 0xAA55; buf[1] = sizeof(buf) / 2; checksum = buf[0]; checksum ^= buf[1];
        for ( uint16_t i = 2; i < buf[1]; i++ ) {
          delayMicroseconds(_transfer_slowdown_while_reading);
          buf[i] = _transfer16_writeread(0xFFFF);
          if ( i < buf[1] - 1 ) checksum ^= buf[i];
        }
        if ( checksum == buf[buf[1] - 1] ) {
          if ( buf[1] > 4 ) {
            if ( buf[2] == 0x0000 ) {
              uint16_t _slave_array[buf[3]];
              memmove(&_slave_array[0], &buf[5], buf[3] * 2 );
              AsyncMST info; info.packetID = buf[4]; info.slave = chip_select;
              _transfer16_write(0xD0D0); // send confirmation
              SPI_deassert();
              if ( _master_handler != nullptr ) _master_handler(_slave_array, buf[3], info);
            }
            else if ( buf[2] == 0x0001 ) {
              bool odd_or_even = ( (buf[3] % 2) );
              uint8_t _slave_array[buf[3]];
              for ( uint16_t i = 0, j = 0; i < buf[3] / 2; i++ ) {
                _slave_array[j] = buf[5 + i] >> 8;
                _slave_array[j + 1] = (uint8_t)buf[5 + i];
                j += 2;
              }
              if ( odd_or_even ) _slave_array[sizeof(_slave_array) - 1] = buf[buf[1] - 2];
              AsyncMST info; info.packetID = buf[4]; info.slave = chip_select;
              _transfer16_write(0xD0D0); // send confirmation
              SPI_deassert();
              if ( _master_handler_uint8_t != nullptr ) _master_handler_uint8_t(_slave_array, buf[3], info);
            }
            else if ( buf[2] == 0x0002 ) {
              if ( _wire_onReceivefunc != nullptr ) {
                AsyncMST info; info.slave = chip_select; info.port = buf[3];
                _transfer16_write(0xD0D0); // send confirmation
                SPI_deassert();
                _wire_callback_active = 1;
                _wire_callback_readpos = 0;
                mtsca.push_front(buf, buf[1]);
                _wire_onReceivefunc(buf[4], info);
                mtsca.pop_front();
                _wire_callback_active = 0;
              }
            }
          }
          _complete = 1;
        }
      }
    }
    _transfer16_write(0xD0D0); // send confirmation
    SPI_deassert();
    goto CHECK_FOR_REMAINING_DATA;
  }
  return 0;
}



























namespace std {
void __attribute__((weak)) __throw_bad_alloc() __attribute__ ((__noreturn__));
void __attribute__((weak)) __throw_length_error( char const*e) __attribute__ ((__noreturn__));
void __attribute__((weak)) __throw_bad_function_call(void) __attribute__ ((__noreturn__));
}