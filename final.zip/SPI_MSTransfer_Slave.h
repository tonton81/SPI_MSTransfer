/*
  MIT License

  Copyright (c) 2018 Antonio Alexander Brewer (tonton81) - https://github.com/tonton81

  Contributors:
  Tim - https://github.com/Defragster
  Mike - https://github.com/mjs513

  Designed and tested for PJRC Teensy 3.2, 3.5, and 3.6 boards.

  Forum link : https : //forum.pjrc.com/threads/50008-Project-SPI_MSTransfer

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/


#ifndef _SPI_MSTransfer_Slave_H_
#define _SPI_MSTransfer_Slave_H_

#ifndef SPI_MST_DATA_BUFFER_MAX
#define SPI_MST_DATA_BUFFER_MAX 50
#endif

#ifndef SPI_MST_QUEUE_SLOTS
#define SPI_MST_QUEUE_SLOTS 8
#endif

//#define MST_USE_WIRE
//#define MST_USE_ANALOGPINS
//#define MST_USE_EEPROM
//#define MST_USE_SPI
//#define MST_USE_SERIAL1
//#define MST_USE_SERIAL2
//#define MST_USE_SERIAL3
//#define MST_USE_SERIAL4
//#define MST_USE_SERIAL5
//#define MST_USE_SERIAL6

#include <SPI.h>

#if defined(MST_USE_WIRE) 
#include <i2c_t3.h>
#endif

#include "circular_buffer.h"

#if defined(MST_USE_EEPROM) 
#include <EEPROM.h>
#endif

#include <atomic>

struct AsyncMST {
  uint16_t packetID = 0;
  uint8_t error = 0;
};

typedef void (*_slave_handler_ptr)(uint16_t* buffer, uint16_t length, AsyncMST info);
typedef void (*_slave_handler_ptr_uint8_t)(uint8_t* buffer, uint16_t length, AsyncMST info);
typedef void (*_wire_onReceive)(size_t count, AsyncMST info); // wire onReceive

class SPI_MSTransfer_Slave {

  public:
    SPI_MSTransfer_Slave(const char *data);

    uint8_t         transfer(uint8_t *buffer, uint16_t length, uint16_t packetID);
    uint16_t        transfer16(uint16_t *buffer, uint16_t length, uint16_t packetID);
    uint16_t        events();
    void            onTransfer(_slave_handler_ptr handler);
    void            onTransfer(_slave_handler_ptr_uint8_t handler);
    void            begin(SPIClass &SPIWire);
    void            debug(Stream &serial);
    Stream*         debugSerial = nullptr;
    bool            _slave_processing_busy = 0;
    uint32_t        _slave_processing_selftimer = 0;
    bool            _slave_was_reset;
    static          Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> mtsca;
    static          Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> stmca;
    static std::atomic<bool> _slave_queue_active;
    static std::atomic<bool> _slave_dequeue_active;

  private:
#if defined MST_USE_WIRE == 1 
    static  void    receiveEvent0(size_t count); // I2C
    static  void    receiveEvent1(size_t count); // I2C
    static  void    receiveEvent2(size_t count); // I2C
    static  void    receiveEvent3(size_t count); // I2C
#endif //MST_USE_WIRE
    static          _slave_handler_ptr _slave_handler; 
    static          _slave_handler_ptr_uint8_t _slave_handler_uint8_t; 
};
extern SPI_MSTransfer_Slave slave;
#endif