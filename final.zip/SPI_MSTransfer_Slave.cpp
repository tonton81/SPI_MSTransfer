/*
  MIT License

  Copyright (c) 2018 Antonio Alexander Brewer (tonton81) - https://github.com/tonton81

  Contributors:
  Tim - https://github.com/Defragster
  Mike - https://github.com/mjs513

  Designed and tested for PJRC Teensy 3.2, 3.5, and 3.6 boards.

  Forum link : https : //forum.pjrc.com/threads/50008-Project-SPI_MSTransfer_Slave

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/

#include <SPI_MSTransfer_Slave.h>

#include <SPI.h>

#include "circular_buffer.h"

#if defined(MST_USE_WIRE)
#include <i2c_t3.h>
#endif

#if defined(MST_USE_EEPROM)
#include <EEPROM.h>
#endif

#include <atomic>

SPI_MSTransfer_Slave *_slave_pointer;
_slave_handler_ptr SPI_MSTransfer_Slave::_slave_handler = nullptr; // SLAVE
_slave_handler_ptr_uint8_t SPI_MSTransfer_Slave::_slave_handler_uint8_t = nullptr; // SLAVE
Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> SPI_MSTransfer_Slave::mtsca; // SLAVE
Circular_Buffer<uint16_t, SPI_MST_QUEUE_SLOTS, SPI_MST_DATA_BUFFER_MAX> SPI_MSTransfer_Slave::stmca; // SLAVE
std::atomic<bool> SPI_MSTransfer_Slave::_slave_queue_active = ATOMIC_FLAG_INIT; // SLAVE
std::atomic<bool> SPI_MSTransfer_Slave::_slave_dequeue_active = ATOMIC_FLAG_INIT; // SLAVE
volatile uint8_t sSPI_port = 0; // SLAVE SPI PORT
volatile uint32_t sSPI_port_gpioloop = 0x01; // SLAVE SPI PORT ISR PIN LOOP
volatile uint32_t spi_mst_spi_addr = 0; // SPI addressing
volatile uint32_t spi_mst_gpiodir_addr = 0; // SPI pin dir addressing

void SPI_MSTransfer_Slave::onTransfer(_slave_handler_ptr handler) {
  _slave_handler = handler;
}
void SPI_MSTransfer_Slave::onTransfer(_slave_handler_ptr_uint8_t handler) {
  _slave_handler_uint8_t = handler;
}
void SPI_MSTransfer_Slave::debug(Stream &serial) {
  debugSerial = &serial;
  Serial.print("] CB Capacity: "); Serial.print(_slave_pointer->SPI_MSTransfer_Slave::mtsca.capacity());
  Serial.print(" Length: "); Serial.println(_slave_pointer->SPI_MSTransfer_Slave::mtsca.max_size());
}

uint8_t SPI_MSTransfer_Slave::transfer(uint8_t *buffer, uint16_t length, uint16_t packetID) {
  uint16_t len = ( !(length % 2) ) ? ( length / 2 ) : ( length / 2 ) + 1;
  uint16_t data[6 + len], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = length; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = packetID; checksum ^= data[data_pos]; data_pos++;
  bool odd_or_even = ( (length % 2) );
  for ( uint16_t i = 0; i < length; i += 2 ) {
    if ( odd_or_even ) {
      if ( i + 1 < length ) {
        data[data_pos] = ((uint16_t)(buffer[i] << 8) | buffer[i + 1]); checksum ^= data[data_pos]; data_pos++;
      }
      else {
        data[data_pos] = buffer[i]; checksum ^= data[data_pos]; data_pos++;
      }
    }
    else {
      data[data_pos] = ((uint16_t)(buffer[i] << 8) | buffer[i + 1]); checksum ^= data[data_pos]; data_pos++;
    }
  }
  data[data_pos] = checksum;
  _slave_queue_active = 1;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
  _slave_queue_active = 0;
  return packetID;
  return 0;
}
uint16_t SPI_MSTransfer_Slave::transfer16(uint16_t *buffer, uint16_t length, uint16_t packetID) {
  uint16_t data[6 + length], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = length; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = packetID; checksum ^= data[data_pos]; data_pos++;
  for ( uint16_t i = 0; i < length; i++ ) {
    data[data_pos] = buffer[i];
    checksum ^= data[data_pos];
    data_pos++;
  }
  data[data_pos] = checksum;
  _slave_queue_active = 1;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
  _slave_queue_active = 0;
  return packetID;
  return 0;
}
void SPI_MSTransfer_Slave::begin(SPIClass &SPIWire) {

  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* KINETIS L SERIES */////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
#if defined(KINETISL)


  Serial.begin(115200); // usb serial
  NVIC_SET_PRIORITY(IRQ_USBOTG, 0);

  while (!Serial && millis() < 5000 );

  Serial.print("\n\tTeensy LC Detected.\n\n\t\tCircular buffer capacity: "); Serial.print(mtsca.capacity());
  Serial.print("\n\t\tCircular buffer length:   "); Serial.println(mtsca.max_size());
  Serial.print("\n\tNote: For LC, SPI0 max is (BUS/4) = 6MHz, SPI1 max is (SYS/4) = 12MHz"); 
  Serial.print("\n\t      Although these are the max speeds, it runs more stable at 4 and 11MHz respectively.\n");
  Serial.print("\n\tAvailable remote controlled resources:\n\tUSBSerial, gpio, ");
#if defined(MST_USE_WIRE)
  Serial.print("Wire, ");
#endif
#if defined(MST_USE_ANALOGPINS)
  Serial.print("analog, ");
#endif
#if defined(MST_USE_EEPROM)
  Serial.print("Eeprom, ");
#endif
#if defined(MST_USE_SPI)
  Serial.print("SPI, ");
#endif
#if defined(MST_USE_SERIAL1)
  Serial.print("Serial1, ");
#endif
#if defined(MST_USE_SERIAL2)
  Serial.print("Serial2, ");
#endif
#if defined(MST_USE_SERIAL3)
  Serial.print("Serial3, ");
#endif
#if defined(MST_USE_SERIAL4)
  Serial.print("Serial4, ");
#endif
#if defined(MST_USE_SERIAL5)
  Serial.print("Serial5, ");
#endif
#if defined(MST_USE_SERIAL6)
  Serial.print("Serial6");
#endif
Serial.println();

  if ( &SPIWire == &SPI ) {
    Serial.print("\n\tUsing SPI0 as slave, pin configuration:\n\n\t\t  Slave:\t\t   Master:\n\n");
    Serial.print("\t\t  CS    2 -------------->  CS\n");
    Serial.print("\t\t  MOSI 11 -------------->  MISO\n");
    Serial.print("\t\t  MISO 12 -------------->  MOSI\n");
    Serial.print("\t\t  SCK  14 -------------->  SCK\n");
  }
  if ( &SPIWire == &SPI1 ) {
    Serial.print("\n\tUsing SPI1 as slave, pin configuration:\n\n\t\t  Slave:\t\t   Master:\n\n");
    Serial.print("\t\t  CS    6 -------------->  CS\n");
    Serial.print("\t\t  MOSI  0 -------------->  MISO\n");
    Serial.print("\t\t  MISO  5 -------------->  MOSI\n");
    Serial.print("\t\t  SCK  20 -------------->  SCK\n");
  }

#if defined(MST_USE_SERIAL1)
  Serial1.begin(115200);
  Serial1.setRX(3);
  Serial1.setTX(4);
  NVIC_SET_PRIORITY(IRQ_UART0_STATUS , 0);
#endif
#if defined(MST_USE_SERIAL2)
  Serial2.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART1_STATUS , 0);
#endif
#if defined(MST_USE_SERIAL3)
  Serial3.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART2_STATUS , 0);
#endif

#if defined(MST_USE_WIRE)
  Wire.onReceive(receiveEvent0);
  Wire1.onReceive(receiveEvent1);
#endif

  if ( &SPIWire == &SPI1 ) {

    // SPI1 is slave, so set SPI as master
    SPI.setSCK(14); SPI.setMOSI(11); SPI.setMISO(12); SPI.begin();
    SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    NVIC_SET_PRIORITY(IRQ_SPI0 , 0);

    spi_mst_gpiodir_addr = 0x400FF0D0; // GPIOD_PDIR
    spi_mst_spi_addr = 0x40077000; // SPI1 SLAVE MEMORYMAP
    SIM_SCGC4 |= SIM_SCGC4_SPI1; // enable slave clock
    SIM_SCGC5 |= SIM_SCGC5_PORTE; // enable port
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 = ((uint8_t)0b00000000); // disable spi
    CORE_PIN20_CONFIG = PORT_PCR_MUX(2); // only one clock for SPI1
    CORE_PIN0_CONFIG = PORT_PCR_DSE | PORT_PCR_MUX(2); // 21 does NOT work!
    CORE_PIN5_CONFIG = PORT_PCR_MUX(2); // only 5 and 1 work!
    CORE_PIN6_CONFIG = PORT_PCR_PE | PORT_PCR_PS | PORT_PCR_MUX(2); // this uses pin 6 for the CS so Serial2 can be used instead.
    sSPI_port_gpioloop = 0x10; // use pin 6 for ISR
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C2 = ((uint8_t)0b01000000);
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).BR = ((uint8_t)0b00000000);
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 = ((uint8_t)0b11101100);
    NVIC_SET_PRIORITY(IRQ_SPI1, 1); // set priority
    NVIC_ENABLE_IRQ(IRQ_SPI1); // enable CS IRQ
  }
  else {
    // SPI is slave, so set SPI1 as master
    SPI1.setSCK(20); SPI1.setMOSI(21); SPI1.setMISO(5); SPI1.setCS(6); SPI1.begin();
    SPI1.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
#if defined(MST_USE_SERIAL2)
    Serial2.setTX(10); // reclaim pin for Serial2.
#endif
    NVIC_SET_PRIORITY(IRQ_SPI1 , 0);

    spi_mst_gpiodir_addr = 0x400FF0D0; // GPIOD_PDIR
    spi_mst_spi_addr = 0x40076000; // SPI0 SLAVE MEMORYMAP
    SIM_SCGC4 |= SIM_SCGC4_SPI0; // enable slave clock
    SIM_SCGC5 |= SIM_SCGC5_PORTA | SIM_SCGC5_PORTC; // enable ports
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 = ((uint8_t)0b00000000); // disable spi
    CORE_PIN14_CONFIG = PORT_PCR_MUX(2);
    CORE_PIN11_CONFIG = PORT_PCR_DSE | PORT_PCR_MUX(2);
    CORE_PIN12_CONFIG = PORT_PCR_MUX(2);
    CORE_PIN2_CONFIG = PORT_PCR_PE | PORT_PCR_PS | PORT_PCR_MUX(2); // this uses pin 2 for the CS so Serial2 can be used instead.
    sSPI_port_gpioloop = 0x01; // use pin 2 for ISR
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C2 = ((uint8_t)0b01000000);
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).BR = ((uint8_t)0b00000000);
    (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 = ((uint8_t)0b11101100);
    NVIC_SET_PRIORITY(IRQ_SPI0, 1); // set priority
    NVIC_ENABLE_IRQ(IRQ_SPI0); // enable CS IRQ
  }
  NVIC_SET_PRIORITY(IRQ_I2C0, 0);
  NVIC_SET_PRIORITY(IRQ_I2C1, 0);
#endif // KINETISL
  /////////////////////////* KINETIS L SERIES */////////////////////////////////////












  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* KINETIS K SERIES */////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)

  Serial.begin(115200); // usb serial
  NVIC_SET_PRIORITY(IRQ_USBOTG, 0);

  while (!Serial && millis() < 5000 );

#if defined(__MK20DX256__)
  Serial.print("\n\tTeensy 3.2 Detected.\n\n\t\tCircular buffer capacity: "); Serial.print(mtsca.capacity());
  Serial.print("\n\t\tCircular buffer length:   "); Serial.println(mtsca.max_size());
#elif defined(__MK64FX512__)
  Serial.print("\n\tTeensy 3.5 Detected.\n\n\t\tCircular buffer capacity: "); Serial.print(mtsca.capacity());
  Serial.print("\n\t\tCircular buffer length:   "); Serial.println(mtsca.max_size());
#elif defined(__MK66FX1M0__)
  Serial.print("\n\tTeensy 3.6 Detected.\n\n\t\tCircular buffer capacity: "); Serial.print(mtsca.capacity());
  Serial.print("\n\t\tCircular buffer length:   "); Serial.println(mtsca.max_size());
#endif
  Serial.print("\n\tAvailable remote controlled resources:\n\tUSBSerial, gpio, ");
#if defined(MST_USE_WIRE)
  Serial.print("Wire, ");
#endif
#if defined(MST_USE_ANALOGPINS)
  Serial.print("analog, ");
#endif
#if defined(MST_USE_EEPROM)
  Serial.print("Eeprom, ");
#endif
#if defined(MST_USE_SPI)
  Serial.print("SPI, ");
#endif
#if defined(MST_USE_SERIAL1)
  Serial.print("Serial1, ");
#endif
#if defined(MST_USE_SERIAL2)
  Serial.print("Serial2, ");
#endif
#if defined(MST_USE_SERIAL3)
  Serial.print("Serial3, ");
#endif
#if defined(MST_USE_SERIAL4)
  Serial.print("Serial4, ");
#endif
#if defined(MST_USE_SERIAL5)
  Serial.print("Serial5, ");
#endif
#if defined(MST_USE_SERIAL6)
  Serial.print("Serial6");
#endif
Serial.println();

  if ( &SPIWire == &SPI ) {
    Serial.print("\n\tUsing SPI0 as slave, pin configuration:\n\n\t\t  Slave:\t\t   Master:\n\n");
    Serial.print("\t\t  CS    2 -------------->  CS\n");
    Serial.print("\t\t  MOSI 11 -------------->  MOSI\n");
    Serial.print("\t\t  MISO 12 -------------->  MISO\n");
    Serial.print("\t\t  SCK  14 -------------->  SCK\n");
  }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
  if ( &SPIWire == &SPI1 ) {
    Serial.print("\n\tUsing SPI1 as slave, pin configuration:\n\n\t\t  Slave:\t\t   Master:\n\n");
    Serial.print("\t\t  CS   31 -------------->  CS\n");
    Serial.print("\t\t  MOSI  0 -------------->  MOSI\n");
    Serial.print("\t\t  MISO  1 -------------->  MISO\n");
    Serial.print("\t\t  SCK  32 -------------->  SCK\n");
  }
  if ( &SPIWire == &SPI2 ) {
    Serial.print("\n\tUsing SPI2 as slave, pin configuration:\n\n\t\t  Slave:\t\t   Master:\n\n");
    Serial.print("\t\t  CS   43 -------------->  CS\n");
    Serial.print("\t\t  MOSI 52 -------------->  MOSI\n");
    Serial.print("\t\t  MISO 51 -------------->  MISO\n");
    Serial.print("\t\t  SCK  53 -------------->  SCK\n");
  }
#endif



#if defined(MST_USE_SERIAL1)
  Serial1.begin(115200);
  Serial1.setRX(27);
  Serial1.setTX(26);
  NVIC_SET_PRIORITY(IRQ_UART0_STATUS , 0);
#endif

#if defined(MST_USE_SERIAL2)
  Serial2.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART1_STATUS , 0);
#endif

#if defined(MST_USE_SERIAL3)
  Serial3.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART2_STATUS , 0);
#endif


#if defined(__MK64FX512__) || defined(__MK66FX1M0__) // **************************
#if defined(MST_USE_SERIAL4)
  if ( &SPIWire != &SPI1 ) {
    Serial4.begin(115200);
    NVIC_SET_PRIORITY(IRQ_UART3_STATUS , 0);
  }
#endif

#if defined(MST_USE_SERIAL5)
  Serial5.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART4_STATUS , 0);
#endif

#if defined(MST_USE_SERIAL6)
  Serial6.begin(115200);
  NVIC_SET_PRIORITY(IRQ_UART4_STATUS , 0);
#if defined(__MK64FX512__)
  NVIC_SET_PRIORITY(IRQ_UART5_STATUS, 0);
#endif
#if defined(__MK66FX1M0__)
  NVIC_SET_PRIORITY(IRQ_LPUART0 , 0);
#endif
#endif
#endif // defined(__MK64FX512__) || defined(__MK66FX1M0__) // *************************





#if defined(MST_USE_WIRE)
  Wire.onReceive(receiveEvent0);
  NVIC_SET_PRIORITY(IRQ_I2C0, 0);
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
  Wire1.onReceive(receiveEvent1);
  Wire2.onReceive(receiveEvent2);
  NVIC_SET_PRIORITY(IRQ_I2C1, 0);
  NVIC_SET_PRIORITY(IRQ_I2C2, 0);
#endif
#if defined(__MK66FX1M0__)
  Wire3.onReceive(receiveEvent3);
  NVIC_SET_PRIORITY(IRQ_I2C3, 0);
#endif // defined(__MK64FX512__) || defined(__MK66FX1M0__)
#endif // defined(MST_USE_WIRE)


  //////// Pre-Set SPI busses

#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
  if ( &SPIWire == &SPI ) {
    SPI1.setSCK(20); SPI1.setMOSI(21); SPI1.setMISO(5); SPI1.begin();
    SPI2.setSCK(46); SPI2.setMOSI(44); SPI2.setMISO(45); SPI2.setCS(43); SPI2.begin();
    SPI1.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    SPI2.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    NVIC_SET_PRIORITY(IRQ_SPI1 , 0);
    NVIC_SET_PRIORITY(IRQ_SPI2 , 0);
  }
  if ( &SPIWire == &SPI1 ) {
    SPI.setSCK(14); SPI.setMOSI(11); SPI.setMISO(12); SPI.setCS(15); SPI.begin();
    SPI2.setSCK(46); SPI2.setMOSI(44); SPI2.setMISO(45); SPI2.setCS(43); SPI2.begin();
    SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    SPI2.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    NVIC_SET_PRIORITY(IRQ_SPI0 , 0);
    NVIC_SET_PRIORITY(IRQ_SPI2 , 0);
  }
  if ( &SPIWire == &SPI1 ) {
    SPI.setSCK(14); SPI.setMOSI(11); SPI.setMISO(12); SPI.setCS(15); SPI.begin();
    SPI1.setSCK(20); SPI1.setMOSI(21); SPI1.setMISO(5); SPI1.begin();
    SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    SPI1.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); // default speed
    NVIC_SET_PRIORITY(IRQ_SPI0 , 0);
    NVIC_SET_PRIORITY(IRQ_SPI1 , 0);
  }
#endif




  /////////////////////////* SLAVE PORT MEMORY MAP & CLOCK ENABLE *////////////////////////////////
  if ( &SPIWire == &SPI ) {
    SIM_SCGC6 |= SIM_SCGC6_SPI0; // enable slave clock
    spi_mst_gpiodir_addr = 0x400FF0D0; // GPIOD_PDIR
    spi_mst_spi_addr = 0x4002C000; // SPI0 SLAVE MEMORYMAP
  }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
  if ( &SPIWire == &SPI1 ) {
    SIM_SCGC6 |= SIM_SCGC6_SPI1; // enable slave clock
    spi_mst_gpiodir_addr = 0x400FF050; // GPIOB_PDIR
    spi_mst_spi_addr = 0x4002D000; // SPI1 SLAVE MEMORYMAP
  }
  if ( &SPIWire == &SPI2 ) {
    SIM_SCGC3 |= SIM_SCGC3_SPI2; // enable slave clock
    spi_mst_gpiodir_addr = 0x400FF050; // GPIOB_PDIR
    spi_mst_spi_addr = 0x400AC000; // SPI2 SLAVE MEMORYMAP
  }
#endif


  /////////////////////////* SLAVE REGISTER CONFIG *////////////////////////////////
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR |= SPI_MCR_HALT | SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR = 0x00000000;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR &= ~SPI_MCR_HALT & ~SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).CTAR0 = 0;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR |= SPI_MCR_HALT | SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).CTAR0 = SPI_CTAR_FMSZ(15);
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR &= ~SPI_MCR_HALT & ~SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR |= SPI_MCR_HALT | SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).CTAR0 &= ~(SPI_CTAR_CPOL | SPI_CTAR_CPHA) | 0x00 << 25;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).MCR &= ~SPI_MCR_HALT & ~SPI_MCR_MDIS;
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).RSER = 0x00020000;

  /////////////////////////* SLAVE PIN/INTERRUPT SETUP *////////////////////////////////
  if ( &SPIWire == &SPI ) {
    CORE_PIN14_CONFIG = PORT_PCR_MUX(2);
    CORE_PIN11_CONFIG = PORT_PCR_DSE | PORT_PCR_MUX(2);
    CORE_PIN12_CONFIG = PORT_PCR_MUX(2);
    CORE_PIN2_CONFIG =  PORT_PCR_PE | PORT_PCR_PS | PORT_PCR_MUX(2); // this uses pin 2 for the CS so Serial2 can be used instead.
    sSPI_port_gpioloop = 0x01; // use pin 2 for ISR
    NVIC_SET_PRIORITY(IRQ_SPI0, 1); // set priority
    NVIC_ENABLE_IRQ(IRQ_SPI0); // enable CS IRQ
  }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
  if ( &SPIWire == &SPI1 ) {
    CORE_PIN32_CONFIG = PORT_PCR_MUX(2); // only 32 works for SPI1, NOT 20!
    CORE_PIN0_CONFIG = PORT_PCR_DSE | PORT_PCR_MUX(2); // only 0 works! 21 does NOT work!
    CORE_PIN1_CONFIG = PORT_PCR_MUX(2); // only 1 works, not 5!
    CORE_PIN31_CONFIG = PORT_PCR_PE | PORT_PCR_PS | PORT_PCR_MUX(2); // this uses pin 31 for the CS so Serial2 can be used instead.
    sSPI_port_gpioloop = 0x0400; // use pin 31 for ISR
    NVIC_SET_PRIORITY(IRQ_SPI1, 1); // set priority
    NVIC_ENABLE_IRQ(IRQ_SPI1); // enable CS IRQ
  }
  if ( &SPIWire == &SPI2 ) {
    CORE_PIN52_CONFIG = PORT_PCR_DSE | PORT_PCR_MUX(2); // only 0 works! 21 does NOT work!
    CORE_PIN53_CONFIG = PORT_PCR_MUX(2); // only 32 works for SPI1, NOT 20!
    CORE_PIN51_CONFIG = PORT_PCR_MUX(2); // only 1 works, not 5!
    CORE_PIN43_CONFIG = PORT_PCR_PE | PORT_PCR_PS | PORT_PCR_MUX(2); // this uses pin 31 for the CS so Serial2 can be used instead.
    sSPI_port_gpioloop = 0x100400; // use pin 43 for ISR
    NVIC_SET_PRIORITY(IRQ_SPI2, 1); // set priority
    NVIC_ENABLE_IRQ(IRQ_SPI2); // enable CS IRQ
  }
#endif // PIN/INTERRUPT
#endif // KINETISK
  /////////////////////////* KINETIS K SERIES */////////////////////////////////////

  pinMode(13, OUTPUT); // Enable LED use
}


SPI_MSTransfer_Slave::SPI_MSTransfer_Slave(const char *data) {
  debugSerial = nullptr;
  if ( !strcmp(data, "SLAVE") ) _slave_pointer = this;
}








void mst_spi_isr(void);
void spi0_isr(void) {

  mst_spi_isr();

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF;
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
  (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 &= ~SPI_C1_SPTIE;
#endif
}
void spi1_isr(void) {

  mst_spi_isr();

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF;
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
  (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 &= ~SPI_C1_SPTIE;
#endif
}
void spi2_isr(void) {

  mst_spi_isr();

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF;
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
  (*(KINETISL_SPI_t *)spi_mst_spi_addr).C1 &= ~SPI_C1_SPTIE;
#endif
}

void mst_spi_isr(void) {
  static uint16_t data[SPI_MST_DATA_BUFFER_MAX];
  uint16_t buffer_pos = 0, len = 0, process_crc = 0;
  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* START OF DATA CAPTURE *////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
  while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
      (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xDEAF; data[buffer_pos] = (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR; buffer_pos++;
      if ( buffer_pos >= SPI_MST_DATA_BUFFER_MAX ) return; // BUFFER LENGTH PROTECTION
    }
    if ( data[1] && buffer_pos >= data[1] ) break;
  }

#elif defined(KINETISL) //////////////////////////////////////////////////////////////
  while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
    if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
      data[buffer_pos] = (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL));
      buffer_pos++;
      (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xDE; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0xAD;
      if ( buffer_pos >= SPI_MST_DATA_BUFFER_MAX ) return; // BUFFER LENGTH PROTECTION
    }
    if ( data[1] && buffer_pos >= data[1] ) break;
  }
#endif ///////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  /////////////////////////* END OF DATA CAPTURE *//////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////////////////////////////

  if ( data[1] && buffer_pos >= data[1] ) {
    len = data[1];

    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF F&F SECTION */////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    if ( data[0] == 0x9244 || data[0] == 0x9254 ) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      _slave_pointer->SPI_MSTransfer_Slave::mtsca.push_back(data, len);
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_selftimer = millis();
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms F&F receipt
        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
          (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xBABE;
          if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
            (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
          }
        }
      }

#elif defined(KINETISL) //////////////////////////////////////////////////////////////
      _slave_pointer->SPI_MSTransfer_Slave::mtsca.push_back(data, len);
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_selftimer = millis();
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms F&F receipt
        if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
          if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xBA; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0xBE;
        }
      }
#endif ///////////////////////////////////////////////////////////////////////////////
    }
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF F&F SECTION *///////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF QUEUE ACTIVATION *////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    if ( data[0] == 0x99BB ) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_busy = 1;
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_selftimer = millis();
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms F&F receipt
        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
          (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xBABE;
          if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
            (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
          }
        }
      }

#elif defined(KINETISL)
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_busy = 1;
      _slave_pointer->SPI_MSTransfer_Slave::_slave_processing_selftimer = millis();
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms F&F receipt
        if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
          if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xBA;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0xBE;
        }
      }
#endif
    }
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF QUEUE ACTIVATION *//////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF STATUS CHECK REQUEST *////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    if ( data[0] == 0x98BB && data[2] == 0x98B8 ) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms STATUS receipt
        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
          uint16_t _notify_status = 0xAD00;
          if ( _slave_pointer->SPI_MSTransfer_Slave::stmca.size() ) _notify_status |= 1 << 0;
          if ( _slave_pointer->SPI_MSTransfer_Slave::mtsca.size() ) _notify_status |= 1 << 1;
          if ( _slave_pointer->SPI_MSTransfer_Slave::_slave_was_reset ) _notify_status |= 1 << 2;
          (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = _notify_status;
          if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
            (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
          }
        }
      }

#elif defined(KINETISL)
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms STATUS receipt
        if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
          if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
          uint16_t _notify_status = 0xAD00;
          if ( _slave_pointer->SPI_MSTransfer_Slave::stmca.size() ) _notify_status |= 1 << 0;
          if ( _slave_pointer->SPI_MSTransfer_Slave::mtsca.size() ) _notify_status |= 1 << 1;
          if ( _slave_pointer->SPI_MSTransfer_Slave::_slave_was_reset ) _notify_status |= 1 << 2;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = (uint8_t)(_notify_status >> 8);
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = (uint8_t)_notify_status;
        }
      }
#endif
    }
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF STATUS CHECK REQUEST *//////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF RESET FLAG UNSET COMMAND *////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    if ( data[0] == 0x98BC && data[2] == 0x98BF ) {
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      _slave_pointer->SPI_MSTransfer_Slave::_slave_was_reset = 0;
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms STATUS receipt
        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
          (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xBABE;
          if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) break;
        }
      }
#elif defined(KINETISL)
      _slave_pointer->SPI_MSTransfer_Slave::_slave_was_reset = 0;
      while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms STATUS receipt
        if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
          if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xBA;
          (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0xBE;
        }
      }
#endif
    }
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF RESET FLAG UNSET COMMAND *//////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////


    /* BEGIN PROCESSING */

    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF CRC VERIFICATION SECTION *////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    for ( uint16_t i = 0; i < len - 1; i++ ) process_crc ^= data[i];
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
    while ( 1 ) { // wait here until MASTER confirms ACK receipt
      if ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & 0x01) ) {
        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
          if ( data[len - 1] != process_crc ) {
            (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xBAAD; (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR;
          }
          else {
            (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = 0xF00D;
            if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xBEEF ) break;
          }
        }
      }
      else {
        (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
      }
    }
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
    while ( 1 ) { // wait here until MASTER confirms ACK receipt
      if ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) { // wait here until MASTER confirms ACK receipt
        if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
          if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xBEEF ) break; // continue ISR
          if ( data[len - 1] != process_crc ) {
            (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xBA; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0xAD;
          }
          else {
            (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = 0xF0; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = 0x0D;
          }
        }
      }
      else return;
    }
#endif ///////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF CRC VERIFICATION SECTION *//////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* START OF DEBUG CRC VERIFICATION SECTION *//////////////
    //////////////////////////////////////////////////////////////////////////////////
    if ( data[len - 1] != process_crc ) {
      if ( _slave_pointer->SPI_MSTransfer_Slave::debugSerial != nullptr ) {
        Serial.print("DEBUG: [CRC FAIL ISR] [DATA] ");
        for ( uint16_t i = 0; i < len; i++ ) {
          Serial.print(data[i], HEX); Serial.print(" ");
        } Serial.println(); Serial.flush();
      }
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
      return;
#endif
    }
    if ( _slave_pointer->SPI_MSTransfer_Slave::debugSerial != nullptr &&
         data[0] != 0x9712 && // block T16 STM RQST
         data[0] != 0x9766 && // block PIN DBG
         data[0] != 0x9253 && // block T8 DBG
         data[0] != 0x9243 ) { // block T16 DBG
      Serial.print("DEBUG: [DATA] ");
      for ( uint16_t i = 0; i < len; i++ ) {
        Serial.print(data[i], HEX); Serial.print(" ");
      } Serial.println(); Serial.flush();
    }
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////////* END OF DEBUG CRC VERIFICATION SECTION *////////////////
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////





    switch ( data[0] ) {

      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF GPIO SECTION *////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x9766: {
          switch ( data[2] ) {
            case 0x0000: { // SLAVE DIGITALWRITE(FAST) CONTROL
                ::digitalWriteFast(data[3] >> 8, data[3]);
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL) //////////////////////////////////////////////////////////////
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif ///////////////////////////////////////////////////////////////////////////////
              }

            case 0x0001: { // SLAVE DIGITALREAD(FAST) CONTROL
                uint16_t buf_pos = 0, buf[4] = { 0xAA55, 4, 0, 0xAA51 };
                if ( ::digitalReadFast(data[3]) ) {
                  buf[2] = 1; buf[3] = 0xAA50;
                }
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }
#elif defined(KINETISL) //////////////////////////////////////////////////////////////
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif ///////////////////////////////////////////////////////////////////////////////
              }

            case 0x0002: { // SLAVE PINMODE CONTROL
                ::pinMode(data[3] >> 8, data[3]);
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL) //////////////////////////////////////////////////////////////
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif ///////////////////////////////////////////////////////////////////////////////
              }

            case 0x0003: { // SLAVE PIN TOGGLE, code written by defragster
                if ( LED_BUILTIN == data[3] ) GPIOC_PTOR = 32;
                else digitalWriteFast(data[3], !digitalReadFast(data[3]));
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL) //////////////////////////////////////////////////////////////
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif ///////////////////////////////////////////////////////////////////////////////
              }
          }
        }

      case 0x9243: { // MASTER SENDS PACKET TO SLAVE QUEUE WITH CRC ACKNOWLEDGEMENT (UINT16_T)
          switch ( data[2] ) {
            case 0x0000: {
                _slave_pointer->SPI_MSTransfer_Slave::mtsca.push_back(data, len);
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, data[4], checksum ^= data[4] };

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }


      case 0x9253: { // MASTER SENDS PACKET TO SLAVE QUEUE WITH CRC ACKNOWLEDGEMENT (UINT8_T)
          switch ( data[2] ) {
            case 0x0000: {
                _slave_pointer->SPI_MSTransfer_Slave::mtsca.push_back(data, len);
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, data[4], checksum ^= data[4] };

#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }

      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* END OF TRANSFER SECTION *//////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////



      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF QUEUE SEND SECTION *//////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x9712: {
          switch ( data[2] ) {
            case 0x0000: {
                if ( !_slave_pointer->SPI_MSTransfer_Slave::_slave_queue_active ) { // IF QUEUES EXIST, ONE WILL BE DEQUEUED TO MASTER
                  if ( !_slave_pointer->SPI_MSTransfer_Slave::stmca.size() ) {
                    uint16_t buf_pos = 0, buf[] = { 0xAA55, 4, 0, 0xAA51 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                    while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                      if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                        (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                          (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                        }
                      }
                    }

#elif defined(KINETISL)
                    while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                      if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                        if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                        uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                        (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                      }
                    }
#endif
                  }
                  else {
                    uint16_t buf_pos = 0;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                    while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                      if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                        (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = _slave_pointer->SPI_MSTransfer_Slave::stmca.front()[ ( buf_pos > _slave_pointer->SPI_MSTransfer_Slave::stmca.front()[1] ) ? buf_pos = 0 : buf_pos++];
                        if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                          _slave_pointer->SPI_MSTransfer_Slave::stmca.pop_front();
                          (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                        }
                      }
                    }
#elif defined(KINETISL)
                    while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                      if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                        if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) {
                          _slave_pointer->SPI_MSTransfer_Slave::stmca.pop_front(); return;
                        }
                        if ( buf_pos > (uint16_t)(_slave_pointer->SPI_MSTransfer_Slave::stmca.front()[1]) ) buf_pos = 0;
                        uint16_t val = (uint16_t)(_slave_pointer->SPI_MSTransfer_Slave::stmca.front()[buf_pos]);
                        buf_pos++;
                        (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                      }
                    }
#endif
                  }
                }
                else { // OTHERWISE, SEND MINIMAL PACKET FOR NO QUEUES
                  uint16_t buf_pos = 0, buf[] = { 0xAA55, 4, 0, 0xAA51 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                      if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                        (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                      }
                    }
                  }

#elif defined(KINETISL)
                  while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                    if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                      if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                      uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                      (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                    }
                  }
#endif
                }
              }
          }
        }
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* END OF QUEUE SEND SECTION *////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////






      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF SERIAL SECTION *//////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x3235: {
          switch ( data[2] ) {
            case 0x0000: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Serial.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      Serial1.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      Serial2.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      Serial3.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      Serial4.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      Serial5.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      Serial6.begin((uint32_t)data[4] << 16 | data[5]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0001: {
                int16_t _read = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      _read = Serial.read(); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      _read = Serial1.read(); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      _read = Serial2.read(); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      _read = Serial3.read(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      _read = Serial4.read(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      _read = Serial5.read(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      _read = Serial6.read(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)_read, checksum ^= (uint16_t)_read };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0002: {
                int16_t _available = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      _available = Serial.available(); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      _available = Serial1.available(); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      _available = Serial2.available(); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      _available = Serial3.available(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      _available = Serial4.available(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      _available = Serial5.available(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      _available = Serial6.available(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)_available, checksum ^= (uint16_t)_available };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0003: {
                int16_t _peek = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      _peek = Serial.peek(); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      _peek = Serial1.peek(); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      _peek = Serial2.peek(); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      _peek = Serial3.peek(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      _peek = Serial4.peek(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      _peek = Serial5.peek(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      _peek = Serial6.peek(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)_peek, checksum ^= (uint16_t)_peek };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0004: {
                uint16_t _written = 0; uint8_t _buf[data[4]];
                for ( uint16_t i = 0; i < data[4]; i++ ) _buf[i] = data[i + 5];
                switch ( data[3] ) {
                  case 0x0000: {
                      _written = Serial.write(_buf, data[4]); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      _written = Serial1.write(_buf, data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      _written = Serial2.write(_buf, data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      _written = Serial3.write(_buf, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      _written = Serial4.write(_buf, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      _written = Serial5.write(_buf, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      _written = Serial6.write(_buf, data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, _written, checksum ^= _written };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0005: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Serial.flush(); break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      Serial1.flush(); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      Serial2.flush(); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      Serial3.flush(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      Serial4.flush(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      Serial5.flush(); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      Serial6.flush(); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0006: {
                switch ( data[3] ) {
                  case 0x0000: {
                      break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      Serial1.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      Serial2.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      Serial3.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      Serial4.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      Serial5.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      Serial6.setTX(data[4] >> 8, data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0007: {
                switch ( data[3] ) {
                  case 0x0000: {
                      break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      Serial1.setRX(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      Serial2.setRX(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      Serial3.setRX(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      Serial4.setRX(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      Serial5.setRX(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      Serial6.setRX(data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0008: {
                bool value = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      value = Serial1.attachRts(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      value = Serial2.attachRts(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      value = Serial3.attachRts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      value = Serial4.attachRts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      value = Serial5.attachRts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      value = Serial6.attachRts(data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 4, value, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i];
                buf[buf[1] - 1] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0009: {
                bool value = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      break;
                    }
#if defined(MST_USE_SERIAL1)
                  case 0x0001: {
                      value = Serial1.attachCts(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL2)
                  case 0x0002: {
                      value = Serial2.attachCts(data[4]); break;
                    }
#endif
#if defined(MST_USE_SERIAL3)
                  case 0x0003: {
                      value = Serial3.attachCts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL4)
                  case 0x0004: {
                      value = Serial4.attachCts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL5)
                  case 0x0005: {
                      value = Serial5.attachCts(data[4]); break;
                    }
#endif
#if ( defined(__MK64FX512__) || defined(__MK66FX1M0__) ) && defined(MST_USE_SERIAL6)
                  case 0x0006: {
                      value = Serial6.attachCts(data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 4, value, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i];
                buf[buf[1] - 1] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }


        } // END OF UART SECTION
        //////////////////////////////////////////////////////////////////////////////////
        /////////////////////////* END OF SERIAL SECTION *////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////





#if defined(MST_USE_EEPROM)
      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF EEPROM SECTION *//////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x67BB: {
          switch ( data[2] ) {
            case 0x0000: {
                uint16_t val = EEPROM.read(data[3]);
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, val, checksum ^= val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0001: {
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      EEPROM.write(data[3], data[4]);
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) {
                      EEPROM.write(data[3], data[4]); return;
                    }
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0002: {
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      EEPROM.update(data[3], data[4]);
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) {
                      EEPROM.update(data[3], data[4]); return;
                    }
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0003: {
                uint16_t val = EEPROM.length();
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, val, checksum ^= val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0004: { // CRC code Written by Christopher Andrews.
                const unsigned long crc_table[16] = {
                  0x00000000, 0x1db71064, 0x3b6e20c8, 0x26d930ac,
                  0x76dc4190, 0x6b6b51f4, 0x4db26158, 0x5005713c,
                  0xedb88320, 0xf00f9344, 0xd6d6a3e8, 0xcb61b38c,
                  0x9b64c2b0, 0x86d3d2d4, 0xa00ae278, 0xbdbdf21c
                };
                unsigned long crc = ~0L;
                for (int index = 0 ; index < EEPROM.length()  ; ++index) {
                  crc = crc_table[(crc ^ EEPROM[index]) & 0x0f] ^ (crc >> 4);
                  crc = crc_table[(crc ^ (EEPROM[index] >> 4)) & 0x0f] ^ (crc >> 4);
                  crc = ~crc;
                }
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 5, (uint16_t)(crc >> 16), (uint16_t)crc, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i];
                buf[buf[1] - 1] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }
        //////////////////////////////////////////////////////////////////////////////////
        /////////////////////////* END OF EEPROM SECTION *////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
#endif // MST_USE_EEPROM




      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF ANALOG SECTION *//////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x7429: { // ANALOG SECTION
          switch ( data[2] ) {
            case 0x0000: {
                analogReadResolution(data[3]);
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0001: {
                uint16_t val = analogRead(data[3]);
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, val, checksum ^= val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0002: {
                uint32_t val = analogWriteResolution((uint32_t)data[3] << 16 | data[4]);
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 5, (uint16_t)(val >> 16), (uint16_t)val, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i];
                buf[buf[1] - 1] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0003: {
                analogWrite(data[3], data[4]);
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }
                (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }
        //////////////////////////////////////////////////////////////////////////////////
        /////////////////////////* END OF ANALOG SECTION *////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////


#if defined(MST_USE_WIRE)
      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF WIRE SECTION *////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x66AA: {
          switch ( data[2] ) {
            case 0x0000: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.beginTransmission((uint8_t)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.beginTransmission((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.beginTransmission((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.beginTransmission((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0001: {
                uint8_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.endTransmission((uint8_t)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.endTransmission((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.endTransmission((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.endTransmission((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0002: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.setSDA((uint8_t)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.setSDA((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.setSDA((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.setSDA((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0003: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.setSCL((uint8_t)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.setSCL((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.setSCL((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.setSCL((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0004: { // (i2c_mode mode, uint8_t address1, uint8_t address2, uint8_t pinSCL, uint8_t pinSDA, i2c_pullup pullup, uint32_t rate, i2c_op_mode opMode)
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.begin((i2c_mode)data[4], (uint8_t)data[5], (uint8_t)data[6], Wire.i2c_t3::mapSCL((i2c_pins)data[7]), Wire.i2c_t3::mapSDA((i2c_pins)data[8]), (i2c_pullup)data[9], ((uint32_t)(data[10] << 16) | data[11]), (i2c_op_mode)data[12] ); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.begin((i2c_mode)data[4], (uint8_t)data[5], (uint8_t)data[6], Wire1.i2c_t3::mapSCL((i2c_pins)data[7]), Wire1.i2c_t3::mapSDA((i2c_pins)data[8]), (i2c_pullup)data[9], ((uint32_t)(data[10] << 16) | data[11]), (i2c_op_mode)data[12] ); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.begin((i2c_mode)data[4], (uint8_t)data[5], (uint8_t)data[6], Wire2.i2c_t3::mapSCL((i2c_pins)data[7]), Wire2.i2c_t3::mapSDA((i2c_pins)data[8]), (i2c_pullup)data[9], ((uint32_t)(data[10] << 16) | data[11]), (i2c_op_mode)data[12] ); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.begin((i2c_mode)data[4], (uint8_t)data[5], (uint8_t)data[6], Wire3.i2c_t3::mapSCL((i2c_pins)data[7]), Wire3.i2c_t3::mapSDA((i2c_pins)data[8]), (i2c_pullup)data[9], ((uint32_t)(data[10] << 16) | data[11]), (i2c_op_mode)data[12] ); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0005: {
                uint16_t _written = 0; uint8_t _buf[data[4]];
                for ( uint16_t i = 0; i < data[4]; i++ ) _buf[i] = data[i + 5];
                switch ( data[3] ) {
                  case 0x0000: {
                      _written = Wire.write(_buf, (uint8_t)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      _written = Wire1.write(_buf, (uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      _written = Wire2.write(_buf, (uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      _written = Wire3.write(_buf, (uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, _written, checksum ^= _written };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0006: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.setClock(((uint32_t)data[4] << 16 | data[5])); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.setClock(((uint32_t)data[4] << 16 | data[5])); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.setClock(((uint32_t)data[4] << 16 | data[5])); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.setClock(((uint32_t)data[4] << 16 | data[5])); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0007: {
                int16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.available(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.available(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.available(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.available(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0008: {
                int16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.read(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.read(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.read(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.read(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0009: {
                int16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.peek(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.peek(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.peek(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.peek(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0010: {
                uint8_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.requestFrom(data[4], data[5], data[6]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.requestFrom(data[4], data[5], data[6]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.requestFrom(data[4], data[5], data[6]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.requestFrom(data[4], data[5], data[6]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0011: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.setRate(((uint32_t)(data[4] << 16) | data[5]), (i2c_rate)((uint32_t)(data[6] << 16) | data[7])); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.setRate(((uint32_t)(data[4] << 16) | data[5]), (i2c_rate)((uint32_t)(data[6] << 16) | data[7])); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.setRate(((uint32_t)(data[4] << 16) | data[5]), (i2c_rate)((uint32_t)(data[6] << 16) | data[7])); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.setRate(((uint32_t)(data[4] << 16) | data[5]), ((uint32_t)(data[6] << 16) | data[7])); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0012: {
                uint16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.setOpMode((i2c_op_mode)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.setOpMode((i2c_op_mode)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.setOpMode((i2c_op_mode)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.setOpMode((i2c_op_mode)data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0013: {
                uint32_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.getClock(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.getClock(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.getClock(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.getClock(); break;
                    }
#endif
                }
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 5, (uint16_t)(val >> 16), (uint16_t)val, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i]; buf[4] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0014: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.resetBus(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.resetBus(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.resetBus(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.resetBus(); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0015: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.sendTransmission((i2c_stop)data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.sendTransmission((i2c_stop)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.sendTransmission((i2c_stop)data[4]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.sendTransmission((i2c_stop)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0016: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.sendRequest((uint8_t)data[4], ((uint32_t)(data[5] << 16) | data[6]), (i2c_stop)data[7]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.sendRequest((uint8_t)data[4], ((uint32_t)(data[5] << 16) | data[6]), (i2c_stop)data[7]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.sendRequest((uint8_t)data[4], ((uint32_t)(data[5] << 16) | data[6]), (i2c_stop)data[7]); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.sendRequest((uint8_t)data[4], ((uint32_t)(data[5] << 16) | data[6]), (i2c_stop)data[7]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0017: {
                switch ( data[3] ) {
                  case 0x0000: {
                      Wire.setDefaultTimeout(((uint32_t)(data[4] << 16) | data[5])); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      Wire1.setDefaultTimeout(((uint32_t)(data[4] << 16) | data[5])); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      Wire2.setDefaultTimeout(((uint32_t)(data[4] << 16) | data[5])); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      Wire3.setDefaultTimeout(((uint32_t)(data[4] << 16) | data[5])); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0018: {
                uint16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.getSDA(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.getSDA(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.getSDA(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.getSDA(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0019: {
                uint16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.getSCL(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.getSCL(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.getSCL(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.getSCL(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0020: {
                uint16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.done(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.done(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.done(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.done(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0021: {
                uint16_t val = 0;
                switch ( data[3] ) {
                  case 0x0000: {
                      val = Wire.finish(); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      val = Wire1.finish(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      val = Wire2.finish(); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      val = Wire3.finish(); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, (uint16_t)val, checksum ^= (uint16_t)val };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0022: {
                uint8_t _available = 0;
                uint32_t _size = 0, count = 0;
                if ( data[3] == 0 ) _available = Wire.available();
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                else if ( data[3] == 1 ) _available = Wire1.available();
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                else if ( data[3] == 2 ) _available = Wire2.available();
#endif
#if defined(__MK66FX1M0__)
                else if ( data[3] == 3 ) _available = Wire3.available();
#endif
                ( ((uint32_t)(data[4] << 16) | data[5]) >= _available ) ? _size = _available : _size = ((uint32_t)(data[4] << 16) | data[5]);
                uint8_t myData[_size];
                switch ( data[3] ) {
                  case 0x0000: {
                      count = Wire.read(myData, _size); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      count = Wire1.read(myData, _size); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      count = Wire2.read(myData, _size); break;
                    }
#endif
#if defined(__MK66FX1M0__)
                  case 0x0003: {
                      count = Wire3.read(myData, _size); break;
                    }
#endif
                }
                uint16_t checksum = 0, buf_pos = 0, buf[5 + count] = { 0xAA55, (uint16_t)(5UL + count), (uint16_t)(count >> 16), (uint16_t)count };
                for ( uint16_t i = 0; i < count; i++ ) buf[i + 4] = myData[i];
                for ( uint16_t i = 0; i < count + 4; i++ ) checksum ^= buf[i];
                buf[buf[1] - 1] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }
        //////////////////////////////////////////////////////////////////////////////////
        /////////////////////////* END OF WIRE SECTION *//////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
#endif // MST_USE_WIRE








#if defined(MST_USE_SPI)
      //////////////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      /////////////////////////* START OF SPI SECTION */////////////////////////////////
      //////////////////////////////////////////////////////////////////////////////////
      case 0x6A7B: {
          switch ( data[2] ) {
            case 0x0000: { // TRANSFER(U8)
                uint16_t response = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      response = SPI.transfer(data[4]); break;
                    }
#if defined(KINETISL) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0001: {
                      response = SPI1.transfer(data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      response = SPI2.transfer(data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, response, checksum ^= response };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0001: { // TRANSFER(U16)
                uint16_t response = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      response = SPI.transfer16(data[4]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      response = SPI1.transfer16(data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      response = SPI2.transfer16(data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, response, checksum ^= response };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0002: { // BEGINTRANSACTION
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.beginTransaction(SPISettings(((uint32_t)(data[4] << 16) | data[5]), data[6], data[7])); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.beginTransaction(SPISettings(((uint32_t)(data[4] << 16) | data[5]), data[6], data[7])); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.beginTransaction(SPISettings(((uint32_t)(data[4] << 16) | data[5]), data[6], data[7])); break;
                    }
#endif
                }
                if ( (int8_t)data[8] >= 0 ) ::digitalWriteFast((int8_t)data[8], data[9]);
                uint16_t buf_pos = 0, buf[] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0003: { // TRANSFER(U32)
                uint16_t responseH = 0, responseL = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      responseH = SPI.transfer16(data[4]);
                      responseL = SPI.transfer16(data[5]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      responseH = SPI1.transfer16(data[4]);
                      responseL = SPI1.transfer16(data[5]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      responseH = SPI2.transfer16(data[4]);
                      responseL = SPI2.transfer16(data[5]); break;
                    }
#endif
                }
                uint16_t checksum = 0, buf_pos = 0, buf[] = { 0xAA55, 5, responseH, responseL, checksum };
                for ( uint16_t i = 0; i < buf[1] - 1; i++ ) checksum ^= buf[i]; buf[4] = checksum;
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0004: { // ENDTRANSACTION
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.endTransaction(); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.endTransaction(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.endTransaction(); break;
                    }
#endif
                }
                if ( (int8_t)data[4] >= 0 ) ::digitalWriteFast((int8_t)data[4], !data[5]);
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0005: {
                uint16_t _written = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI.transfer16(data[i + 5]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI1.transfer16(data[i + 5]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI2.transfer16(data[i + 5]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, _written, checksum ^= _written };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0006: {
                uint16_t _written = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI.transfer((uint8_t)(data[i + 5])); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI1.transfer((uint8_t)(data[i + 5])); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      _written = data[4];
                      for ( uint16_t i = 0; i < data[4]; i++ ) SPI2.transfer((uint8_t)(data[i + 5])); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, _written, checksum ^= _written };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0007: { // SETCS()
                uint16_t response = 0;
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      response = SPI.setCS((uint8_t)data[4]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      response = SPI1.setCS((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      response = SPI2.setCS((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t checksum = 0xAA51, buf_pos = 0, buf[] = { 0xAA55, 4, response, checksum ^= response };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0008: { // SETMOSI()
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.setMOSI((uint8_t)data[4]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.setMOSI((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.setMOSI((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0009: { // SETMISO()
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.setMISO((uint8_t)data[4]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.setMISO((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.setMISO((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0010: { // SETSCK()
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.setSCK((uint8_t)data[4]); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.setSCK((uint8_t)data[4]); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.setSCK((uint8_t)data[4]); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
            case 0x0011: { // BEGIN()
                switch ( data[3] ) { // PORT
                  case 0x0000: {
                      SPI.begin(); break;
                    }
#if defined(__MK64FX512__) || defined(__MK66FX1M0__) || defined(KINETISL)
                  case 0x0001: {
                      SPI1.begin(); break;
                    }
#endif
#if defined(__MK64FX512__) || defined(__MK66FX1M0__)
                  case 0x0002: {
                      SPI2.begin(); break;
                    }
#endif
                }
                uint16_t buf_pos = 0, buf[3] = { 0xAA55, 3, 0xAA56 };
#if defined(__MK20DX256__) || defined(__MK64FX512__) || defined(__MK66FX1M0__)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR & 0xF0 ) {
                    (*(KINETISK_SPI_t *)spi_mst_spi_addr).PUSHR = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    if ( (*(KINETISK_SPI_t *)spi_mst_spi_addr).POPR == 0xD0D0 ) {
                      (*(KINETISK_SPI_t *)spi_mst_spi_addr).SR |= SPI_SR_RFDF; return;
                    }
                  }
                }

#elif defined(KINETISL)
                while ( !((*(volatile uint32_t *)spi_mst_gpiodir_addr) & sSPI_port_gpioloop) ) {
                  if ( (*(KINETISL_SPI_t *)spi_mst_spi_addr).S & SPI_S_SPTEF ) {
                    if ( (((*(KINETISL_SPI_t *)spi_mst_spi_addr).DH) << 8 | ((*(KINETISL_SPI_t *)spi_mst_spi_addr).DL)) == 0xD0D0 ) return;
                    uint16_t val = buf[ ( ++buf_pos > buf[1] -1 ) ? buf_pos = 0 : buf_pos];
                    (*(KINETISL_SPI_t *)spi_mst_spi_addr).DH = val >> 8; (*(KINETISL_SPI_t *)spi_mst_spi_addr).DL = val;
                  }
                }
#endif
              }
          }
        }
        //////////////////////////////////////////////////////////////////////////////////
        /////////////////////////* END OF SPI SECTION *///////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
#endif // MST_USE_SPI









    }
  }
}


uint16_t SPI_MSTransfer_Slave::events() {
  _slave_dequeue_active = 1;
  if ( _slave_pointer->SPI_MSTransfer_Slave::mtsca.size() > 0 ) {
    uint16_t array[_slave_pointer->SPI_MSTransfer_Slave::mtsca.front()[1]];
    _slave_pointer->SPI_MSTransfer_Slave::mtsca.pop_front(array, sizeof(array) / 2 );
    if ( array[0] == 0x9254 || array[0] == 0x9253  ) {
      uint16_t checksum = 0; AsyncMST info; info.packetID = array[4];
      for ( uint16_t i = 0; i < array[1] - 1; i++ ) checksum ^= array[i];
      ( checksum == array[array[1] - 1] ) ? info.error = 0 : info.error = 1;
      bool odd_or_even = ( (array[3] % 2) );
      uint8_t buf[array[3]];
      for ( uint16_t i = 0, j = 0; i < array[3] / 2; i++ ) {
        buf[j] = array[5 + i] >> 8;
        buf[j + 1] = (uint8_t)array[5 + i];
        j += 2;
      }
      if ( odd_or_even ) buf[sizeof(buf) - 1] = array[array[1] - 2];
      if ( _slave_handler_uint8_t != nullptr ) _slave_handler_uint8_t(buf, array[3], info);
    }
    if ( array[0] == 0x9244 || array[0] == 0x9243 ) {
      uint16_t checksum = 0, buf[array[3]]; AsyncMST info; info.packetID = array[4];
      for ( uint16_t i = 0; i < array[1] - 1; i++ ) checksum ^= array[i];
      ( checksum == array[array[1] - 1] ) ? info.error = 0 : info.error = 1;
      memmove (&buf[0], &array[5], array[3] * 2 );
      if ( _slave_handler != nullptr ) _slave_handler(buf, array[3], info);
    }
  }
  _slave_dequeue_active = 0;
  return 0;
}



















#if defined(MST_USE_WIRE)
void SPI_MSTransfer_Slave::receiveEvent0(size_t count) {
  uint16_t data[6 + count], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = 0x0000; checksum ^= data[data_pos]; data_pos++; // I2C PORT
  data[data_pos] = count; checksum ^= data[data_pos]; data_pos++;
  for ( uint16_t i = 0; i < count; i++ ) {
    data[data_pos] = Wire.read();
    checksum ^= data[data_pos];
    data_pos++;
  }
  data[data_pos] = checksum;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
}
void SPI_MSTransfer_Slave::receiveEvent1(size_t count) {
  uint16_t data[6], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = 0x0001; checksum ^= data[data_pos]; data_pos++; // I2C PORT
  data[data_pos] = count; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
}
void SPI_MSTransfer_Slave::receiveEvent2(size_t count) {
  uint16_t data[6], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // I2C PORT
  data[data_pos] = count; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
}
void SPI_MSTransfer_Slave::receiveEvent3(size_t count) {
  uint16_t data[6], checksum = 0, data_pos = 0;
  data[data_pos] = 0xAA55; checksum ^= data[data_pos]; data_pos++; // HEADER
  data[data_pos] = sizeof(data) / 2; checksum ^= data[data_pos]; data_pos++; // DATA SIZE
  data[data_pos] = 0x0002; checksum ^= data[data_pos]; data_pos++; // SUB SWITCH STATEMENT
  data[data_pos] = 0x0003; checksum ^= data[data_pos]; data_pos++; // I2C PORT
  data[data_pos] = count; checksum ^= data[data_pos]; data_pos++;
  data[data_pos] = checksum;
  _slave_pointer->SPI_MSTransfer_Slave::stmca.push_back(data, data[1]);
}
#endif // MST_USE_WIRE

namespace std {
void __attribute__((weak)) __throw_bad_alloc() __attribute__ ((__noreturn__));
void __attribute__((weak)) __throw_length_error( char const*e) __attribute__ ((__noreturn__));
void __throw_bad_function_call(void) __attribute__ ((__noreturn__));
}

SPI_MSTransfer_Slave slave = SPI_MSTransfer_Slave("SLAVE");